R = [10 20 30 -20];
L = [1.7e-3 2.1e-3 4.9e-3 2.1e-3];
C = [1e-6 2e-6 3e-6 2e-6];
K = ([10 1000 0.1 100 1000]);

%P
for i = 1:4
    tau = L(i)/R(i);
    T_F = (tf([K(i)/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]));
    
    figure(1);
    subplot(2,4,i);
    title('Step');
    step(T_F);
    
    subplot(2,4,i+4);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([K(i)/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    S = stepinfo(T_F)
    figure(2);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);    
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)))
    w_n  = (1/(sqrt(L(i)*C(i))))
    
end
hold off;

% I
for i = 1:4
    tau = L(i)/R(i);
    T_F = (tf([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i))),0]))
    
    figure(3);
    subplot(2,4,i);
    title('Step');
    step(T_F);
    
    subplot(2,4,i+4);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i))),0]);
    S = stepinfo(T_F)
    figure(4);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);    
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)))
    w_n  = (1/(sqrt(L(i)*C(i))))
    
end
hold off;

% D
for i = 1:4
    tau = L(i)/R(i);
    T_F = (tf([1/(L(i)*C(i)),0],[1,(1/tau),(1/(L(i)*C(i)))]))
    
    figure(5);
    subplot(2,4,i);
    title('Step');
    step(T_F);
    
    subplot(2,4,i+4);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i)),0],[1,(1/tau),(1/(L(i)*C(i)))]);
    S = stepinfo(T_F)
    figure(6);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);    
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)))
    w_n  = (1/(sqrt(L(i)*C(i))))
    
end
hold off;

%% Comparision Analysis
 %Second order open loopwith controller
%P controller
% Only peak value of the system is changes

%I controller
%For I controller the system become unstable
%For one pole it is marginally stable

%D controoler 
%For D controller speed of the system is more
%In this settling time is also less
