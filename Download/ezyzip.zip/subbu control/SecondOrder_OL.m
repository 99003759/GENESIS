%% Control system - RLC circuit - Second Order System 
% Name - Katherapalle rama subba reddy
% PS No - 99003759
% Date - 07/04/2021
% Version - 2.0

%% plant description
% implementation
%This plant has a model for RLC circuit. 
%The 3 different values of R, L and C are analyzed 

% Equation = V(t) = I(t)R + L{dI(t)/dt} + {1/C}{int(I(t)dt)}
% V(t) = I(t)R + L{\frac{dI(t)}{dt}} + \frac{1}{C}  \int I(t)dt

%% Math analysis
% I- Time
% D- V,I
% C- R,L,C
%roots = −(ξ∗Wn)±√(ξ^2−1)    << $-(\xi*W_n) \pm \sqrt{(\xi^2 - 1)}$ >>

%% Tool Analysis


R = [10 20 30];
L = [1.7e-3 2.1e-3 4.9e-3];
C = [1e-6 2e-6 3e-6];

for i = 1:3
    tau = L(i)/R(i);
    T_F = tf([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))])
    
    figure(1);
    subplot(2,3,i);
    title('Step');
    step(T_F);
    
    subplot(2,3,i+3);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    S = stepinfo(T_F)
    figure(2);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)));
    w_n  = (1/(sqrt(L(i)*C(i))));    
end

%% Comparision Analysis
% Speed
% Has the poles of the transfor function moves away from the origin  
% The rise time is decreasing so the response of the system is speed
%Accuracy
%  Has the poles of the transfor function moves away from the origin
% The settling time is decreasing so the accuracy is more
%Stability
% For the transfor functions above the poles negative side so they are stable 