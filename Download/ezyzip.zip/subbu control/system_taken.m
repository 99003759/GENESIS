%%open loop
%fist order system which choosen
%%Tool anyalasis
q = ([3 5 10]);
v = ([25 200 2000]);
K = ([100 1000 0.1]);

for i=1:3
    Tau = v(i)/q(i);
    Lf = tf([0 1],[Tau 1])
    figure(1);
    subplot(2,3,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,3,i+3);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([0 1],[Tau 1]);
    figure(2);
    zplane(z,p);
    xlim([-30e-3 30e-3]);
    ylim([-30e-3 30e-3]);
    hold on;
    stepinfo(Lf)
end
hold off;

%closed loop

q = ([3 5 10]);
v = ([25 200 2000]);
% Positive Feedback
for i=1:3
    Tau = v(i)/q(i);
    Lf = (tf([0 1],[Tau 0]))
    figure(1);
    subplot(2,4,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,4,i+4);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([0 1],[Tau 0]);
    figure(2);
    zplane(z,p);
    xlim([-30 600]);
    ylim([-100 100]);
    hold on;
    stepinfo(Lf)
end
hold off;

% Negative Feedback with and without PID

q = ([3 5 10]);
v = ([25 200 2000]);

for i = 1:3
    Tau = v(i)/q(i);
    sys_ol = tf([0 1],[Tau 2]);
    sys_cl = feedback(sys_ol,1);
    
    [GC_PI,info_PI] = pidtune(sys_ol,'PI');
     sys_cl_PI = feedback(sys_ol * GC_PI,1);
    
    [GC_PD,info_PD] = pidtune(sys_ol,'PD');
    sys_cl_PD = feedback(sys_ol * GC_PD,1);
    
    [GC_PID,info_PID] = pidtune(sys_ol,'PID');
    sys_cl_PID = feedback(sys_ol * GC_PID,1);

% input response plots
    figure(3);
    subplot(4,3,i);
    step(sys_ol);
    title(['Step of ', num2str(i) ,'th OL TF']);
    
    subplot(4,3,i+3);
    impulse(sys_ol);
    title(['impulse of ', num2str(i) ,'th OL TF']);
        
    subplot(4,3,i+6);
    step(sys_cl);
    title(['Step of ', num2str(i) ,'th CL TF']);
    
    subplot(4,3,i+9);
    impulse(sys_cl);
    title(['impulse of ', num2str(i) ,'th CL TF']);

% controller plots
    figure(4);
    subplot(4,3,i);
    step(sys_cl)
    title(['CL Uncontrolled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+3);
    step(sys_cl_PI)
    title(['CL PI controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+6);
    step(sys_cl_PD)
    title(['CL PD controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+9);
    step(sys_cl_PID)
    title(['CL PID controlled response of ', num2str(i) ,'th TF']);
    
% Bode plots
    figure(5);
    subplot(3,3,i);
    bode(sys_ol)
    title(['OL of ',num2str(i),'th TF']);
    
    subplot(3,3,i+3);
    bode(sys_cl)
    title(['CL uncontrolled ',num2str(i),'th TF']);
    
    subplot(3,3,i+6);
    bode(sys_cl_PID)
    title(['CL PID controlled ',num2str(i),'th TF']);
    
end

%%Comparision Analysis
% Speed
% Has the poles of the transfor function moves away from the origin  
% The rise time is decreasing so the response of the system is speed
%Accuracy
%  Has the poles of the transfor function moves away from the origin
% The settling time is decreasing so the accuracy is more
%Stability
% For the transfor functions above the poles negative side so they are stable 

%positive feed back
%For some values of RL system is become unstable
