%% Control system - RL circuit - First Order System 
% Name - Katherapalle rama subba reddy
% PS No - 99003759
% Date - 07/04/2021
% Version - 2.0

%% Plant Description
% implementation
%This plant has a model for RLC circuit. 
%The 3 different values of R, L and C are analyzed

% equation- V(t)= I(t)R + L{dI(t)/dt}  //V(t) = I(t)R + L{\frac{dI(t)}{dt}} 

%% Math analysis
% I- t 
% D- V,I
% C- R,L
% Roots calculation
%           IVT     FVT
% Impulse-  1/L     0 
% % Step   -  0     1/R

% Time Response 
% Sys1                          Sys2                        Sys3
%  RiseTime: 1.0985e-05         RiseTime: 2.1970e-05        RiseTime: 1.0985e-04
%  SettlingTime: 1.9560e-05     SettlingTime: 3.9121e-05    SettlingTime: 1.9560e-04
%  SettlingMin: 0.9045          SettlingMin: 0.9045         SettlingMin: 0.9000
%  SettlingMax: 1.0000          SettlingMax: 1.0000         SettlingMax: 1.0000
%  Overshoot: 0                 Overshoot: 0                Overshoot: 0
%  Undershoot: 0                Undershoot: 0               Undershoot: 0
%  Peak: 1.0000                 Peak: 1.0000                Peak: 1.0000
%  PeakTime: 5.2729e-05         PeakTime: 1.0546e-04        PeakTime: 5.2729e-04

%% Tool Analysis

%R = ([10e3 1e3 0.1e3]);
%L = ([50e-3 10e-3 5e-3]);
R = ([100 100e-3 0.32e-3 -100e-3]);
L = ([5 25e-3 2e-3 25e-3]);

for i=1:3
    Tau = L(i)/R(i);
    Lf = tf([0 (1/R(i))],[Tau 1])
    figure(1);
    subplot(2,3,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,3,i+3);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([0 (1/R(i))],[Tau 1]);
    figure(2);
    zplane(z,p);
%     xlim([-4*1e5 2*1e5]);
%     ylim([-4*1e5 2*1e5]);
    xlim([-30 30]);
    ylim([-30 30]);
    hold on;
    stepinfo(Lf)
end
hold off;

%% Comparision Analysis
%first order open loop
% Speed
% Has the poles of the transfor function moves away from the origin  
% The rise time is decreasing so the response of the system is speed
%Accuracy
% Has the poles of the transfor function moves away from the origin
% The settling time is decreasing so the accuracy is more
%Stability
% For the transfor functions above the poles negative side so they are stable 
