
poles = [-100+0i -150+0i -230-100i -280-100i -50+450i -50-450i 125+200i ...
          125-200i -200+200i -200-200i -200+350i -200-350i];
zeros = [0 0];
gain = 0.8;
s=zpk(zeros,poles,gain);
pzplot(s)
xlim([-350 150]);
ylim([-500 500]);

[Wn,zeta]=damp(s)
stepinfo(poles)