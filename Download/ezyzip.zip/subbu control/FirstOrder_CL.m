%% Control system - RL circuit - First Order System 
% Name - Katherapalle rama subba reddy
% PS No - 99003759
% Date - 08/04/2021
% Version - 2.0

%% Tool Analysis
R = ([100 100e-3 0.32e-3 -100e-3]);
L = ([5 25e-3 2e-3 25e-3]);
K = ([10 1000 0.1 100]);

% Positive Feedback
for i=1:4
    Tau = L(i)/R(i);
    Lf = (tf([(1/R(i))],[Tau (1-(1/R(i)))]));
    figure(1);
    subplot(2,4,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,4,i+4);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([(1/R(i))],[Tau (1-(1/R(i)))]);
    figure(2);
    zplane(z,p);
    xlim([-30 600]);
    ylim([-100 100]);
    hold on;
    stepinfo(Lf);
end
hold off;

%Negative Feedback with and without PID

% R = ([10e3 1e3 0.1e3]);
% L = ([50e-3 10e-3 5e-3]);

for i = 1:3
    Tau = L(i)/R(i);
    sys_ol = tf([0 1],[Tau 1]);
    sys_cl = feedback(sys_ol,1)
    stepinfo(sys_ol)
    
    [GC_PI,info_PI] = pidtune(sys_ol,'PI');
     sys_cl_PI = feedback(sys_ol * GC_PI,1);
      stepinfo(sys_cl_PI);
    
    [GC_PD,info_PD] = pidtune(sys_ol,'PD');
    sys_cl_PD = feedback(sys_ol * GC_PD,1);
    stepinfo(sys_cl_PD);
    
    [GC_PID,info_PID] = pidtune(sys_ol,'PID');
    sys_cl_PID = feedback(sys_ol * GC_PID,1);
    stepinfo(sys_cl_PID)

% input response plots
    figure(3);
    subplot(4,3,i);
    step(sys_ol);
    title(['Step of ', num2str(i) ,'th OL TF']);
    
    subplot(4,3,i+3);
    impulse(sys_ol);
    title(['impulse of ', num2str(i) ,'th OL TF']);
        
    subplot(4,3,i+6);
    step(sys_cl);
    title(['Step of ', num2str(i) ,'th CL TF']);
    
    subplot(4,3,i+9);
    impulse(sys_cl);
    title(['impulse of ', num2str(i) ,'th CL TF']);

% controller plots
    figure(4);
    subplot(4,3,i);
    step(sys_cl)
    title(['CL Uncontrolled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+3);
    step(sys_cl_PI)
    title(['CL PI controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+6);
    step(sys_cl_PD)
    title(['CL PD controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+9);
    step(sys_cl_PID)
    title(['CL PID controlled response of ', num2str(i) ,'th TF']);
    
% Bode plots
    figure(5);
    subplot(3,3,i);
    bode(sys_ol)
    title(['OL of ',num2str(i),'th TF']);
    
    subplot(3,3,i+3);
    bode(sys_cl)
    title(['CL uncontrolled ',num2str(i),'th TF']);
    
    subplot(3,3,i+6);
    bode(sys_cl_PID)
    title(['CL PID controlled ',num2str(i),'th TF']);
    
end

%% Comparision Analysis
% First order system of closed loop
%positive feed postive feed back
%in this the is unstable for positive feedback

%Negative feedback
%In this speed of the system increases as poles goes away from origin
%In this Settling time also decreases as poles goes away from origin
%In this system peak value is same for all poles

%PI controller
%Rise time decreases so the speed of the system
%Settling time also decreased so more accurate
%peak cvalue is increased

%PD controller
%Rise time decreased in this system so it more speed
%Settling time also decreased 
%Peak values also decreased

%PID  controller
%Rise time decreases so some what speed
%Settling time also slightly decreases 
%peak value also decreases