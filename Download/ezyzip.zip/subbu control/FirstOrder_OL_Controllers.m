%% Control system - RL circuit - First Order System 
% Name - Katherapalle rama subba reddy
% PS No - 99003759
% Date - 08/04/2021
% Version - 2.0

%% Tool Analysis
R = ([100 100e-3 0.32e-3 -100e-3]);
L = ([5 25e-3 2e-3 25e-3]);
K = ([10 1000 0.1 100]);

% P
for i=1:4

    Tau = L(i)/R(i);
    Lf = K(i)*(tf([0 (1/R(i))],[Tau 1]))
    figure(1);
    subplot(2,4,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,4,i+4);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([0 (1/R(i))],[Tau 1]);
    figure(2);
    zplane(z,p);
    xlim([-25 10]);
    ylim([-10 10]);
    hold on;
    stepinfo(Lf)
end
hold off;

% I
for i=1:4

    Tau = L(i)/R(i);
    Lf = (tf([0 (1/R(i))],[Tau 1 0]))
    figure(3);
    subplot(2,4,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,4,i+4);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([0 (1/R(i))],[Tau 1 0]);
    figure(4);
    zplane(z,p);
    pzmap(Lf);
    xlim([-40 40]);
    ylim([-40 40]);
    hold on;
    stepinfo(Lf)
end
hold off;

% D
for i=1:4
    Tau = L(i)/R(i);
    Lf = (tf([(1/R(i)) 0],[Tau 1]))
    figure(5);
    subplot(2,4,i);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,4,i+4);
    step(Lf);
    title('Step Input');
    hold on;
    [z,p,k]= tf2zp([(1/R(i)) 0],[Tau 1]);
    figure(6);
    zplane(z,p);
    pzmap(Lf);
    xlim([-40 40]);
    ylim([-40 40]);
    hold on;
    stepinfo(Lf)
end
hold off;

%% Comparision Analysis
%P controller
%Speed
%Has the poles of the transfor function moves away from the origin
%The rise time is decreasing so the response of the system is speed
%Accuracy
%  Has the poles of the transfor function moves away from the origin
% The settling time is decreasing so the accuracy is more
%Stability
% For the transfor functions above the poles negative side so they are stable 
% In this p controller only the peak value of the system increases

% I controller
%In this I controller the system become unstable 
%beacause the poles of the system are in positive side
% It is also marginarlly stable pole located in origin


% D controoler
% In this controller rise time and settling time is same as before
%But overshoot is increased and peak value also increases