%% Control system - RLC circuit - Second Order System 
% Name - Katherapalle rama subba reddy
% PS No - 99003759
% Date - 08/04/2021
% Version - 2.0

%% Tool Analysis
R = [10 20 30];
L = [1.7e-3 2.1e-3 4.9e-3];
C = [1e-6 2e-6 3e-6];

for i = 1:3
    tau = L(i)/R(i);
    sys_ol = tf([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    stepinfo(sys_ol)
    sys_cl = feedback(sys_ol,1)
    stepinfo(sys_cl);
    
    [GC_PI,info_PI] = pidtune(sys_ol,'PI');
     sys_cl_PI = feedback(sys_ol * GC_PI,1);
    stepinfo(sys_cl_PI);
     
    [GC_PD,info_PD] = pidtune(sys_ol,'PD');
    sys_cl_PD = feedback(sys_ol * GC_PD,1);
    
    stepinfo(sys_cl_PD);
    [GC_PID,info_PID] = pidtune(sys_ol,'PID');
    sys_cl_PID = feedback(sys_ol * GC_PID,1);
    stepinfo(sys_cl_PID)

% input response plots
    figure(1);
    subplot(4,3,i);
    step(sys_ol);
    title(['Step of ', num2str(i) ,'th OL TF']);
    
    subplot(4,3,i+3);
    impulse(sys_ol);
    title(['impulse of ', num2str(i) ,'th OL TF']);
        
    subplot(4,3,i+6);
    step(sys_cl);
    title(['Step of ', num2str(i) ,'th CL TF']);
    
    subplot(4,3,i+9);
    impulse(sys_cl);
    title(['impulse of ', num2str(i) ,'th CL TF']);

% controller plots
    figure(2);
    subplot(4,3,i);
    step(sys_cl)
    title(['CL Uncontrolled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+3);
    step(sys_cl_PI)
    title(['CL PI controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+6);
    step(sys_cl_PD)
    title(['CL PD controlled response of ', num2str(i) ,'th TF']);
    
    subplot(4,3,i+9);
    step(sys_cl_PID);
    title(['CL PID controlled response of ', num2str(i) ,'th TF']);
    
% Bode plots
    figure(3);
    subplot(3,3,i);
    bode(sys_ol)
    title(['OL of ',num2str(i),'th TF']);
    
    subplot(3,3,i+3);
    bode(sys_cl)
    title(['CL uncontrolled ',num2str(i),'th TF']);
    
    subplot(3,3,i+6);
    bode(sys_cl_PID)
    title(['CL PID controlled ',num2str(i),'th TF']);
    
end


%% Comparision Analysis
%Second order closed loop with unity feed back
%In this the speed is also slightly decreased
%Settling time does not effect in this unity feedback

%second order with controllers
%PI controller
%In this system speed is decreased so respose is some slow
%In this system settling time is slightly differed
%Peak valve of the system also decreases

%PD 
%In this system speed increased
%In this system settling time is also decreases
%peak value also decreases

%PID
%In this system speed of the system decrease
%In this system settling time also varies
%peak value also decreases


