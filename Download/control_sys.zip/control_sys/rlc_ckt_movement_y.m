%% This script defines the movement of poles along Y axis
% There are 2 real and distinct poles for the given values of constants.
% As the poles move along left side of s plane ( with more negative value
% of poles) the systems seems more stable.

%%
poles = [-250+433i -250-433i 125+216.506i 125-216.506i -125+216.506i -125-216.506i];
zeros = [0 0];
gain = 0.8;
s=zpk(zeros,poles,gain);
pzplot(s)
xlim([-350 150]);
ylim([-500 500]);

[Wn,zeta]=damp(s)

%%Tool Analysis:

% The calculated values of the pole placement is verified with the plot
% obtained.