%% Control system : 1st Order System ANALYSIS
% Name      : Rajendra Hanagodi
% Ps no     : 99003740
% Date      : 07/04/2021
% version   : 1.0
%% plant description
% This plant has a model for RL circuit.the 3 different values of R and 
% L are analyzed 
% Equation from the plant in time domain  :  V(t)=I(t)R+LI'(t)

%% Math analysis
% Independent   :  Time(t)
% Dependent     :  Voltage(V),Current(I)
% Constant      :  Resistence(R),Inductance(L)

% Roots         :  -(R/L)

%IVT :
%1.For step input :0


R = ([100 100e-3 0.32e-3 -100e-3]);
L = ([5 25e-3 2e-3 25e-3]);

 

for i=1:4

    Tau = L(i)/R(i);
    Lf = tf([0 1],[Tau 1]);
    figure(i);
    subplot(3,1,1);
    impulse(Lf);
    title('Impulse Input');
    subplot(3,1,2);
    step(Lf);
    title('Step Input');
    [z,p,k]= tf2zp([0 1],[Tau 1]);
    figure(5);
    zplane(z,p);
    xlim([-30 30]);
    ylim([-30 30]);
    hold on;
    S = stepinfo(Lf);
    
    
end