R = [10 20 30 -20];
L = [1.7e-3 2.1e-3 4.9e-3 2.1e-3];
C = [1e-6 2e-6 3e-6 2e-6];
K = ([10 1000 0.1 100 1000]);


for i = 1:4
    tau = L(i)/R(i);
    T_F = K(i) * (tf([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]));
    
    figure(i);
    subplot(2,1,1);
    title('Step');
    step(T_F);
    
    subplot(2,1,2);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    S = stepinfo(T_F)
    figure(5);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);    
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)))
    w_n  = (1/(sqrt(L(i)*C(i))))
    
end
hold off;