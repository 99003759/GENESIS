R = ([10 5e3 10e3 -5e-3]);
L = ([10 1.8 0.3 1.8]);
K = ([10 1000 0.1 100]);
for i=1:4

    Tau = L(i)/R(i);
    Lf = K(i)*(tf([0 1],[Tau 1]))
    figure(i);
    subplot(2,1,1);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,1,2);
    step(Lf);
    title('Step Input');
    [z,p,k]= tf2zp([0 1],[Tau 1]);
    figure(5);
    zplane(z,p);
    xlim([-4000 4000]);
    ylim([-4000 4000]);
    hold on;
    S = stepinfo(Lf);

end
