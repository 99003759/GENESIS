%% Control system : 1st Order System ANALYSIS
% Name      : Rajendra Hanagodi
% Ps no     : 99003740
% Date      : 07/04/2021
% version   : 1.0
%% plant description
% This plant has a model for RL circuit.the 3 different values of R and 
% L are analyzed 
% Equation from the plant in time domain  :  V(t)=I(t)R+LI'(t)

%% Math analysis
% Independent   :  Time(t)
% Dependent     :  Voltage(V),Current(I)
% Constant      :  Resistence(R),Inductance(L)

% Roots         :  -(R/L)

%IVT :
%1.For step input :0


R = ([10e3 1e3 0.1e3]);
L = ([50e-3 10e-3 5e-3]);

 

for i=1:3

    Tau = L(i)/R(i);
    Lf = tf([0 1],[Tau 1]);
    figure(i);
    subplot(3,1,1);
    impulse(Lf);
    title('Impulse Input');
    subplot(3,1,2);
    step(Lf);
    title('Step Input');
    [z,p,k]= tf2zp([0 1],[Tau 1]);
    figure(4);
    zplane(z,p);
    xlim([-4*1e5 2*1e5]);
    ylim([-4*1e5 2*1e5]);
    hold on;
    S = stepinfo(Lf);
    
    
end