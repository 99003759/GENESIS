%% Control system: 2nd Order System Analysis
% Name      :  Rajendra Hanagodi
% Ps no     :  99003740
% Date      :  07/04/2021
% version   :  1.0
%% plant description
% This plant has a model for RLC circuit.The 3 different values of R,L 
% and C are analyzed
% Equation from the plant in time domain  :

%% Math analysis
% Independent   :  Time(t)
% Dependent     :  Voltage(V),Current(I)
% Constant      :  Resistence(R),Capacitor(C),Inductance(L)

% Roots         :  -(R/L)


%Poles and Zeros


R = [10 20 30];
L = [1.7e-3 2.1e-3 4.9e-3];
C = [1e-6 2e-6 3e-6];

for i = 1:3
    tau = L(i)/R(i);
    T_F = tf([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    ss(T_F)
    
    figure(i);
    subplot(2,1,1);
    title('Step');
    step(T_F);
    
    subplot(2,1,2);
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i))],[1,(1/tau),(1/(L(i)*C(i)))]);
    S = stepinfo(T_F);
    figure(4);
    zplane(z,p);
    xlim([-30000 30000]);
    ylim([-30000 30000]);
    hold on;
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)));
    w_n  = (1/(sqrt(L(i)*C(i))));
    
end
hold off;