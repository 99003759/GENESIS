R = [10 20 30];
L = [1.7e-3 2.1e-3 4.9e-3];
C = [1e-6 2e-6 3e-6];

for i = 1:3
    tau = L(i)/R(i);
    T_F = tf([1/(L(i)*C(i))],[1 (1/tau) 0]);
    
    figure(i)
    subplot(2,1,1)
    title('Step')
    step(T_F);
    
    subplot(2,1,2)
    title('impulse')
    impulse(T_F);
    
    [z,p,k]= tf2zp([1/(L(i)*C(i))],[1 (1/tau) 0]);
    S = stepinfo(T_F);
    figure(4)
    zplane(z,p);
    xlim([-10000 2000])
    ylim([-3000 3000])
    hold on
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)))
    w_n  = (1/(sqrt(L(i)*C(i))))
    
end
hold off;