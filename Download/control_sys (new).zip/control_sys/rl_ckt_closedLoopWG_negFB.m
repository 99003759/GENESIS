R = ([100 100e-3 0.32e-3 -100e-3]);
L = ([5 25e-3 2e-3 25e-3]);
K = ([10 1000 0.1 100]);

for i=1:4

    Tau = L(i)/R(i);
    Lf = (tf([(K(i)/R(i))],[Tau (1+K(i)/R(i))]))
    figure(i);
    subplot(2,1,1);
    impulse(Lf);
    title('Impulse Input');
    subplot(2,1,2);
    step(Lf);
    title('Step Input');
    [z,p,k]= tf2zp([(K(i)/R(i))],[Tau (1+K(i)/R(i))]);
    figure(5);
    zplane(z,p);
    pzmap(Lf)
    xlim([-30 30]);
    ylim([-30 30]);
    hold on;
    S = stepinfo(Lf);

end
