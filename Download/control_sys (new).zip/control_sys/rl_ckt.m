%% Control system : 1st Order System ANALYSIS
% Name      : Rajendra Hanagodi
% Ps no     : 99003740
% Date      : 07/04/2021
% version   : 1.0
%% plant description
% This plant has a model for RL circuit.the 3 different values of R and 
% L are analyzed 
% Equation from the plant in time domain  :  V(t)=I(t)R+LI'(t)

%% Math analysis
% Independent   :  Time(t)
% Dependent     :  Voltage(V),Current(I)
% Constant      :  Resistence(R),Inductance(L)

% Roots         :  -(R/L)

%Initial Value Theorem :
%1.For step input :0
%2.For impluse input:1/L

%Final Value Theorem :
%1.For step input : infinity
%2.For impulse input:0



R = ([10e3 1e3 0.1e3]);
L = ([50e-3 10e-3 5e-3]);

 

for i=1:3

    Tau = L(i)/R(i);
    Lf = tf([0 1],[Tau 1]);
    figure(i);
    subplot(3,1,1);
    %impulse input to the transfer function to get impulse response
    impulse(Lf);
    title('Impulse Input');
    subplot(3,1,2);
    %step input to the transfer function to get step response
    step(Lf);
    title('Step Input');
    [z,p,k]= tf2zp([0 1],[Tau 1]);
    figure(4);
    zplane(z,p);
    xlim([-4*1e5 2*1e5]);
    ylim([-4*1e5 2*1e5]);
    hold on;
    S = stepinfo(Lf)
    
    
end

%%Comparison Analysis :(Speed , accuracy and stability)
%Speed OF 1st Order system will be highest. From figure 4 in the 