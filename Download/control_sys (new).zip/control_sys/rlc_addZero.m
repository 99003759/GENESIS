R = ([1e2 475 625 -825]);
L = ([35e-1 15e-1 5e-1 0.3e-1]);
C = [35e-7 15e-7 5e-7 0.3e-7];
K = ([10 1000 0.1 100]);
Z = ([8.163e7 2.444e8 4e8 -1.11e12]);


for i = 1:4
    tau = L(i)/R(i);
    T_F =(tf([(1/(L(i)*C(i))) Z(i)],[1,(1/tau),(1/(L(i)*C(i)))]))
    
    figure(i);
    subplot(2,1,1);
    title('Step');
    step(T_F);
    
    subplot(2,1,2)
    title('impulse');
    impulse(T_F);
    
    [z,p,k]= tf2zp([(1/(L(i)*C(i))) 55],[1,(1/tau),(1/(L(i)*C(i)))]);  
    S = stepinfo(T_F)
    figure(5);
    zplane(z,p);
    pzmap(T_F)
    xlim([-2000 2000]);
    ylim([-2000 2000]);
    hold on
    zeta = (R(i)/2)*(sqrt(C(i)/L(i)));
    w_n  = (1/(sqrt(L(i)*C(i))));
    
end
hold off;