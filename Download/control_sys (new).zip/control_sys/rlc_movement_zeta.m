poles = [-250+450i -250-450i 125+216.506i 125-216.506i -200+216.506i -200-216.506i];
zeros = [0 0];
gain = 0.8;
s=zpk(zeros,poles,gain);
pzplot(s);
xlim([-350 150]);
ylim([-500 500]);

[Wn,zeta]=damp(s)