%%  Define our Plant

n=poly([1/(L(i)*C(i))]);  %defining our numerator
d=poly([-3 -6 -10]);  %defining our denominator 
Ps=tf(n,d)  %tf is a function that calls for a predifined numerator and        %denominator value to create a transfer function
Ts=feedback(Ps,1) %the feedback function will automatically provide you 
                  %with the closed loop transfer function while defining 
                  %your plant as the first variable, and your feedback as
                  %your second variable 

% Once you click on "Run Section" you will note that values have appeared
% in your Workspace and a transfer function as been printed in your 
% Command Window. 
            
%%  Run SISO tool to analyze Plant transfer function

sisotool(Ps)  %Note that we are running sisotool on the open-loop TF

%%  Apply gain & analyze system response

% At this point you can either export your gain (K) value or you can
% manually enter and save the value in your workspace.
K=116.5;  %K as given through siso analysis
Ps1=K*Ps  %Muliplying K with plant
Ts1=feedback(Ps1,1)  %This will provide the closed loop transfer function 
                     %where the feedback line has a value of just 1 
                     %(nothing contained in feedback - unitary feedback)
stepinfo(Ts1)  %stepinfo will print detailed step response data
step(Ts,Ts1);  %will provide a graph of the step response for visual analysis

%% Calculate Goal Peak-Time
Tp=0.2978;  %value of Tp that I found in previous section from stepinfo
Tp_goal=Tp*(2/3)  %printing my goal peak time in command window

pOS = 20;  
dr=-log(pOS/100)/sqrt(pi^2+(log(pOS/100))^2); % OS to Damping Ratio eq.
w=pi/(Tp_goal*sqrt(1-(dr^2)))  % Peak Time and DR to find freq.

%%  Apply PD compensation

% Here we run sisotool again, this time on Ps1 instead of Ps. 
% We will now add an additional design characteristic - our goal peak-time
% Refer to peak-time equation to find settling-time equivalent

sisotool(Ps1)

%%  Export the PD compensator for analysis

PD=C  %Only run this section once to ensure that PD is not overwritten with
      %another C value from SISO tool
Ps2=Ps1*PD
Ts2=feedback(Ps2,1)
stepinfo(Ts2)
step(Ts,Ts1,Ts2)

%%  Apply PID compensation
% As before, we will run sisotool, this time on Ps2 and finalize our PID

sisotool(Ps2)

%%  Export the PID compensator value for analysis

PID=C  % This will carry the value of our new C and attach it to PID
Ps3=Ps2*PID  % muliply the integrator to the PD
Ts3=feedback(Ps3,1)
stepinfo(Ts3)
step(Ts,Ts1,Ts2,Ts3)

%% Finally we will calculate our steady-state error (refer to equations)

kp=dcgain(Ps3); % dcgain is a function that will carry out our limit s->0
ess=1/(1+kp) % this is the equation for the steady state error for a step
%%  Define our Plant

n=poly([-8]);  %defining our numerator
d=poly([-3 -6 -10]);  %defining our denominator 
Ps=tf(n,d)  %tf is a function that calls for a predifined numerator and 
            %denominator value to create a transfer function
Ts=feedback(Ps,1) %the feedback function will automatically provide you 
                  %with the closed loop transfer function while defining 
                  %your plant as the first variable, and your feedback as
                  %your second variable 

% Once you click on "Run Section" you will note that values have appeared
% in your Workspace and a transfer function as been printed in your 
% Command Window. 
            
%%  Run SISO tool to analyze Plant transfer function

sisotool(Ps)  %Note that we are running sisotool on the open-loop TF

%%  Apply gain & analyze system response

% At this point you can either export your gain (K) value or you can
% manually enter and save the value in your workspace.
K=116.5;  %K as given through siso analysis
Ps1=K*Ps  %Muliplying K with plant
Ts1=feedback(Ps1,1)  %This will provide the closed loop transfer function 
                     %where the feedback line has a value of just 1 
                     %(nothing contained in feedback - unitary feedback)
stepinfo(Ts1)  %stepinfo will print detailed step response data
step(Ts,Ts1);  %will provide a graph of the step response for visual analysis

%% Calculate Goal Peak-Time
Tp=0.2978;  %value of Tp that I found in previous section from stepinfo
Tp_goal=Tp*(2/3)  %printing my goal peak time in command window

pOS = 20;  
dr=-log(pOS/100)/sqrt(pi^2+(log(pOS/100))^2); % OS to Damping Ratio eq.
w=pi/(Tp_goal*sqrt(1-(dr^2)))  % Peak Time and DR to find freq.

%%  Apply PD compensation

% Here we run sisotool again, this time on Ps1 instead of Ps. 
% We will now add an additional design characteristic - our goal peak-time
% Refer to peak-time equation to find settling-time equivalent

sisotool(Ps1)

%%  Export the PD compensator for analysis

PD=C  %Only run this section once to ensure that PD is not overwritten with
      %another C value from SISO tool
Ps2=Ps1*PD
Ts2=feedback(Ps2,1)
stepinfo(Ts2)
step(Ts,Ts1,Ts2)

%%  Apply PID compensation
% As before, we will run sisotool, this time on Ps2 and finalize our PID

sisotool(Ps2)

%%  Export the PID compensator value for analysis

PID=C  % This will carry the value of our new C and attach it to PID
Ps3=Ps2*PID  % muliply the integrator to the PD
Ts3=feedback(Ps3,1)
stepinfo(Ts3)
step(Ts,Ts1,Ts2,Ts3)

%% Finally we will calculate our steady-state error (refer to equations)

kp=dcgain(Ps3); % dcgain is a function that will carry out our limit s->0
ess=1/(1+kp) % this is the equation for the steady state error for a step
