%% This script defines the movement of poles along X axis
% There are 2 real and distinct poles for the given values of constants.
% As the poles move along left side of s plane ( with more negative value
% of poles) the systems seems more stable.
%% CODE


poles = [-100+0i -150+0i -230-100i -280-100i -50+450i -50-450i 125+200i ...
          125-200i -200+200i -200-200i -200+350i -200-350i];
zeros = [0 0];
gain = 0.8;
s=zpk(zeros,poles,gain);
pzplot(s)
%xlim([-20 10]);
%ylim([-10 10]);
xlim([-350 150]);
ylim([-500 500]);

[Wn,zeta]=damp(s)

%for i=1:12
    stepinfo(poles)
%end
%%Tool Analysis:

% The calculated values of the pole placement is verified with the plot
% obtained.